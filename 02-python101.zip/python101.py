def hello(str=None):
  """
  This is a sample function that we will try to import and run to ensure that
  our environment is correctly set up on Google Colab.
  """
  print('Hello from python101.py!')
  if str is not None:
    print(str)
  else:
    print('no input')
