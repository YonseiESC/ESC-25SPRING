import matplotlib.pyplot as plt
import numpy as np
import util
import os

from lwr import LocallyWeightedLinearRegression


def main(tau_values, train_path, valid_path, test_path):
    """Problem 5(b): Tune the bandwidth paramater tau for LWR.

    Args:
        tau_values: List of tau values to try.
        train_path: Path to CSV file containing training set.
        valid_path: Path to CSV file containing validation set.
        test_path: Path to CSV file containing test set.
    """
    # Load training set
    x_train, y_train = util.load_dataset(train_path, add_intercept=True)
    # Load validation set
    x_eval, y_eval = util.load_dataset(valid_path, add_intercept=True)
    # Load test set
    x_test, y_test = util.load_dataset(test_path, add_intercept=True)

    ##################### START CODE HERE ##########################
    # Search tau_values for the best tau (lowest MSE on the validation set)
    # Fit a LWR model with the best tau value
    # Run on the test set to get the MSE value
    # Save predictions to pred_eval
    # Plot data

    # Validation
    MSE = None ### TODO ################################
    for tau in tau_values :
        ################################################################
        ########################## TODO ################################
        pass # Make a prediction on the validation set
        pred_eval = np.zeros(x_eval.shape[0])
        MSE = None
        print(f'MSE value for Tau={tau} : {None}')
        ################################################################
        ################################################################

        # Plotting
        plt.figure()
        plt.scatter(x_train[:, 1], y_train, c='b', marker='x', label='Train')
        plt.scatter(x_eval[:, 1], y_eval, c='r', marker='o', label='Eval')
        plt.scatter(x_eval[:, 1], pred_eval, c='g', marker='o', label='Pred')
        plt.xlabel('x')
        plt.ylabel('y')
        plt.legend()
        if not os.path.isdir("result"):
            os.makedirs("result")
        plt.savefig(f'result/q5c_tau{tau}.png')
        plt.close()

    # Test
    ################################################################
    ########################## TODO ################################
    best_tau = 9999
    pass # Make a prediction on the test set
    pred_test = np.zeros((x_test.shape[0], 1))
    MSE = None
    ################################################################
    ################################################################
    print(f'MSE value for Tau={best_tau} : {MSE}')
    
    # Plotting
    plt.figure()
    plt.scatter(x_train[:, 1], y_train, c='b', marker='x', label='Train')
    plt.scatter(x_test[:, 1], y_test, c='r', marker='o', label='Test')
    plt.scatter(x_test[:, 1], pred_test, c='g', marker='o', label='Pred')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.savefig(f'result/q5c_test.png')
    plt.close()
    ##################### END CODE HERE ############################
    