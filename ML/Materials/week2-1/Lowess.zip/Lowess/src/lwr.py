import matplotlib.pyplot as plt
import numpy as np
import util
import os

from linear_model import LinearModel


def main(tau, train_path, eval_path):
    """Problem 5(b): Locally weighted regression (LWR)

    Args:
        tau: Bandwidth parameter for LWR.
        train_path: Path to CSV file containing dataset for training.
        eval_path: Path to CSV file containing dataset for evaluation.
    """
    # Load training set
    x_train, y_train = util.load_dataset(train_path, add_intercept=True)
    # Load validation set
    x_eval, y_eval = util.load_dataset(eval_path, add_intercept=True)

    ##################### START CODE HERE ##########################
    # Fit a LWR model
    # Get MSE value on the validation set
    # Plot validation predictions on top of training set
    # No need to save predictions
    # Plot data

    ################################################################
    ########################## TODO ################################
    pass # Make a prediction on the validation set
    pred_eval = np.zeros(x_eval.shape[0])
    MSE = None
    print(f'MSE value : {MSE}')
    ################################################################
    ################################################################

    # Plotting
    plt.figure()
    plt.scatter(x_train[:, 1], y_train, c='b', marker='x', label='Train')
    plt.scatter(x_eval[:, 1], y_eval, c='r', marker='o', label='Eval')
    plt.scatter(x_eval[:, 1], pred_eval, c='g', marker='o', label='Pred')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    if not os.path.isdir("result"):
        os.makedirs("result")
    plt.savefig('result/q5b.png')
    plt.close()
    ##################### END CODE HERE ############################


class LocallyWeightedLinearRegression(LinearModel):
    """Locally Weighted Regression (LWR).

    Example usage:
        > clf = LocallyWeightedLinearRegression(tau)
        > clf.fit(x_train, y_train)
        > clf.predict(x_eval)
    """

    def __init__(self, tau):
        super(LocallyWeightedLinearRegression, self).__init__()
        self.tau = tau
        self.x = None
        self.y = None

    def fit(self, x, y):
        """Fit LWR by saving the training set.

        """
        ##################### START CODE HERE ##########################

        ################################################################
        ########################## TODO ################################
        self.x = None
        self.y = None
        ################################################################
        ################################################################

        ##################### END CODE HERE ############################

    def predict(self, x):
        """Make predictions given inputs x.

        Args:
            x: Inputs of shape (m, d).

        Returns:
            Outputs of shape (m,).
        """
        ##################### START CODE HERE ##########################
        X = np.copy(self.x) # Train dataset, (N, d)
        y = np.copy(self.y) # Train dataset, label, (N,)
        m, d = x.shape
        yhat = np.zeros(m)

        ################################################################
        ########################## TODO ################################
        ## Hint : Using One-loop is allowed. But it can be implemented without any loop by using vectorization.
        pass
        ################################################################
        ################################################################
        return yhat
        ##################### END CODE HERE ############################