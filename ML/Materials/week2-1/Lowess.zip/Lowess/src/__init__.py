from linear_model import LinearModel
from lwr import LocallyWeightedLinearRegression
from tau import main as tau_main
from lwr import main as lwr_main
from util import add_intercept, load_dataset, plot