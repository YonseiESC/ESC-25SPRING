import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

from src import tau_main, lwr_main

# Run this file(i.e. main.py) to verify your implementation
def main():
    base_path = "data"
    train_path = os.path.join(base_path, "ds5_train.csv")
    valid_path = os.path.join(base_path, "ds5_valid.csv")
    test_path = os.path.join(base_path, "ds5_test.csv")

    lwr_main(0.5, train_path, valid_path)
    tau_values = [0.1, 0.5, 1.0, 5.0]
    tau_main(tau_values, train_path, valid_path, test_path)

if __name__ == "__main__":
    main()