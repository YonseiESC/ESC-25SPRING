import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

from src.poisson_regression import poisson_main
from src.pois_reg_scikit import poisson_sklearn

def main():
    base_path = "data"
    train_path = os.path.join(base_path, "train.csv")
    valid_path = os.path.join(base_path, "valid.csv")
    pred_path_yours = os.path.join(base_path, "pred.txt")
    pred_path_scikit = os.path.join(base_path, "pred_scikit.txt")

    lr = 1e-10
    poisson_main(lr, train_path, valid_path, pred_path_yours)

    poisson_sklearn(train_path, valid_path, pred_path_scikit)

    print(f"Custom model predictions saved to: {pred_path_yours}")
    print(f"Scikit-learn model predictions saved to: {pred_path_scikit}")

if __name__ == "__main__":
    main()