import numpy as np

custom_pred = np.loadtxt("data/pred.txt")
sklearn_pred = np.loadtxt("data/pred_scikit.txt")

diff = np.abs(custom_pred - sklearn_pred)

relative_error = (diff / np.abs(sklearn_pred)) * 100 

print(f"Mean Absolute Difference: {np.mean(diff):.6f}")
print(f"Mean Relative Error (%): {np.mean(relative_error):.6f}%")