import numpy as np
import util

from linear_model import LinearModel


def poisson_main(lr, train_path, valid_path, pred_path):
    """Problem: Poisson regression with gradient ascent.

    Args:
        lr: Learning rate for gradient ascent.
        train_path: Path to CSV file containing dataset for training.
        eval_path: Path to CSV file containing dataset for evaluation.
        pred_path: Path to save predictions.
    """
    # Load training set
    x_train, y_train = util.load_dataset(train_path, add_intercept=False)
    x_eval, _ = util.load_dataset(valid_path, add_intercept=False)

    ############################## START CODE HERE ##############################
    
    ############################### END CODE HERE ###############################


class PoissonRegression(LinearModel):
    """Poisson Regression.

    Example usage:
        > clf = PoissonRegression(step_size=lr)
        > clf.fit(x_train, y_train)
        > clf.predict(x_eval)
    """

    def fit(self, x, y):
        """Run gradient ascent to maximize likelihood for Poisson regression.

        Args:
            x: Training example inputs. Shape (m, n).
            y: Training example labels. Shape (m,).
        """
        ############################## START CODE HERE ##############################
        # max iteration 도달 시 또는 theta의 변화가 일정 수준 미만인 경우 반복을 종료
        
        ############################### END CODE HERE ###############################

    def predict(self, x):
        """Make a prediction given inputs x.

        Args:
            x: Inputs of shape (m, n).

        Returns:
            Floating-point prediction for each input, shape (m,).
        """
        ############################## START CODE HERE ##############################
        
        ############################### END CODE HERE ###############################