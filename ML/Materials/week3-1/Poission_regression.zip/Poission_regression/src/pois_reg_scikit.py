import numpy as np
import util

from sklearn.linear_model import PoissonRegressor

def poisson_sklearn(train_path, valid_path, pred_path):
    '''
    To verify whether your implementation has been done correctly.
    '''
    X_train, y_train = util.load_dataset(train_path, add_intercept=False)
    X_valid, _ = util.load_dataset(valid_path, add_intercept=False)

    model = PoissonRegressor(alpha=0, max_iter=1000, tol=1e-4, verbose=1)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_valid)

    np.savetxt(pred_path, y_pred)
    print(f"Predictions saved to {pred_path}")